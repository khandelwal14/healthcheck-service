# Swagger generated server

1. Install all dependency using npm install
2. Run - npm run dev
