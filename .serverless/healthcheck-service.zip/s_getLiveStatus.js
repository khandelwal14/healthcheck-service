var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ankur2001',
applicationName: 'healthcheck-service',
appUid: 'XWCJcC6tlnfQjmYrjY',
tenantUid: 'X5lwqjy5l7nJ6DZ8BY',
deploymentUid: 'cdd7cbf1-50ba-4a28-9756-661a19f73e21',
serviceName: 'healthcheck-service',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'healthcheck-service-dev-getLiveStatus', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.getLiveStatus, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
